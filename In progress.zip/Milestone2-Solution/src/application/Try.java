package application;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Try extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Create the element to be centered
        Label centeredLabel = new Label("Centered Pane");
        centeredLabel.setStyle("-fx-border-color: green; -fx-border-width: 2px; -fx-padding: 10px;");

        // Create the HBox on the left
        HBox leftBox = new HBox();
        leftBox.setStyle("-fx-background-color: lightblue;");
        leftBox.getChildren().add(new Label("Left Content"));

        // Create the VBox at the bottom
        VBox bottomBox = new VBox();
        bottomBox.setStyle("-fx-background-color: lightyellow;");
        bottomBox.getChildren().add(new Label("Bottom Content"));

        // Create the center pane and set its alignment to center
        StackPane centerPane = new StackPane(centeredLabel);
        centerPane.setStyle("-fx-background-color: lightgray;");

        // Create an empty region for centering within the BorderPane
        Region centerRegion = new Region();
        centerRegion.setStyle("-fx-background-color: transparent;");
        HBox.setHgrow(centerRegion, Priority.ALWAYS);
        VBox.setVgrow(centerRegion, Priority.ALWAYS);

        // Create the BorderPane
        BorderPane borderPane = new BorderPane();

        // Set the left HBox
        borderPane.setLeft(leftBox);

        // Set the center pane and center region
        borderPane.setCenter(centerRegion);
        borderPane.setCenter(centerPane);

        // Set the bottom VBox
        borderPane.setBottom(bottomBox);

        // Create the scene with the BorderPane
        Scene scene = new Scene(borderPane, 400, 300);

        // Set the scene on the stage
        primaryStage.setScene(scene);

        // Show the stage
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
