package model.characters;

public abstract class Character {

}
