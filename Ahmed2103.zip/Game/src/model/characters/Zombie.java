package model.characters;

public class Zombie extends Character {
	public Zombie() {
		
	}
}
