package model.characters;

public abstract class Hero extends Character {
	public Hero() {
		
	}
}
