package model.world;

public abstract class Cell {
	protected Cell() {
		
	}
	boolean isVisible() {
		return false;
	}
}
