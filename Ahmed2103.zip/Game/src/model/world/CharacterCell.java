package model.world;

public class CharacterCell extends Cell {
	private Character character;
	
	public CharacterCell(Character character) {
		this.character = character;
	}
	
	public boolean isSafe() {
		return false;
	}
	
	public Character getCharacter() {
		return character;
	}
	
	public void setCharacter(Character character) {
		this.character = character;
	}
}
