package application;


import java.awt.Point;

import engine.Game;
import exceptions.InvalidTargetException;
import exceptions.MovementException;
import exceptions.NoAvailableResourcesException;
import exceptions.NotEnoughActionsException;
import javafx.application.Platform;
//import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.geometry.Side;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Screen;
import javafx.util.Duration;
import model.characters.Character;
import model.characters.Direction;
import model.characters.Explorer;
import model.characters.Fighter;
import model.characters.Hero;
import model.characters.Medic;
import model.characters.Zombie;
import model.collectibles.Supply;
import model.collectibles.Vaccine;
import model.world.CharacterCell;
import model.world.CollectibleCell;
import model.world.TrapCell;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.animation.ScaleTransition;


public class Play {
	public static Scene play;
	public static Hero selectedHero = Main.selected;
	public static int indexOfSelectedHero = 0;
	public static BorderPane root = new BorderPane();
	public static StackPane cont = new StackPane();
	public static VBox heroes = new VBox();
	public static GridPane map = new GridPane();
	public static ImageButton left = new ImageButton("left.png",70,70,0);
    public static ImageButton right = new ImageButton("right.png",70,70,0);
    public static ImageButton up = new ImageButton("up.png",70,70,0);
    public static ImageButton down = new ImageButton("down.png",70,70,0);
	public static ImageButton attackButton = new ImageButton("sword.png",80,80,100);
    public static ImageButton useSpecialButton = new ImageButton("supply.png",80,80,100);
    public static ImageButton cureButton = new ImageButton("syringe.png",80,80,100);
	public static ImageButton endTurnButton = new ImageButton("endTurn.png",50,100,0);
	public static ImageButton helpButton = new ImageButton("help.png",80,100,0);
	public static boolean running = true;
	public static Button quitButton = new Button("Quit");
	
	public static void start(Hero selected) {
		selectedHero.getSupplyInventory().add(new Supply());
		selectedHero.setTarget(new Zombie());
		map.setVgap(0);
		map.setHgap(0);
		map.setPadding(new Insets(0));
		map.setTranslateX(-40);
		map.setTranslateY(-20);
		heroes.setMinWidth(250);
		selectedHero = selected;
		root.setStyle("-fx-background-color: #0b2239;");
		refreshHeroStats();
		heroes.setTranslateX(20);
		map.setMaxSize(550, 550);
		map.setMinSize(550,550);
		map.setAlignment(Pos.CENTER);
		refreshMap();
		actions();
        GridPane movePane = new GridPane();
        GridPane actionsPane = new GridPane();
    	HBox actionsBox = new HBox(10);
        actionsBox.setPadding(new Insets(20, 40, 30, 40));
        actionsBox.setPrefHeight(300);
        movePane.setPrefSize(500, 500);
        
        attackButton.setTranslateX(5);
        right.setTranslateX(-18);
        down.setTranslateY(13);
        //Set pane properties
        movePane.setHgap(10);
        movePane.setVgap(10); 
        actionsPane.setVgap(20);
        actionsPane.setHgap(10);

        //Add move buttons to a movePane
        movePane.add(left,0,1);
        left.setTranslateX(52);
        movePane.add(down,1,1);
        down.setTranslateY(35);
        movePane.add(right, 2, 1);
        right.setTranslateX(-71);
        movePane.add(up, 1, 0);
        up.setTranslateY(62);
        
        //Add action buttons to actionsPane
        actionsPane.add(attackButton, 0, 0);
        actionsPane.add(useSpecialButton, 1, 0);
        actionsPane.add(endTurnButton,1,1);
        actionsPane.add(cureButton,2,0);
        actionsPane.add(helpButton, 2, 5);
        actionsPane.add(left, 0, 4);
        actionsPane.add(right, 2, 4);
        actionsPane.add(up, 1, 3);
        actionsPane.add(down, 1, 4);

        
        // Create an HBox to hold the buttons
        actionsBox.setAlignment(Pos.CENTER);
        
     // Create a region to fill the space between Move and Attack/Use Special buttons
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        // Add the buttons to the button container
        actionsBox.getChildren().addAll(spacer, actionsPane);
        actionsBox.setTranslateY(-200);
		root.setBottom(actionsBox);
		refreshActionButtons();
		root.setLeft(heroes);
		cont.getChildren().add(root);
		cont.getChildren().add(map);
		// Get the primary screen
        Screen screen = Screen.getPrimary();

        // Get the visual bounds of the screen
        Rectangle2D bounds = screen.getVisualBounds();

        // Retrieve the screen width and height
        double screenWidth = bounds.getWidth();
        double screenHeight = bounds.getHeight();
		play = new Scene(cont,screenWidth,screenHeight);
		eventHandler();
	}
	
	public static void eventHandler(){
	play.setOnKeyPressed(new EventHandler<KeyEvent>(){
		
		@Override
		public void handle(KeyEvent event) {
			switch(event.getCode()) {
				case X: try {
						Game.endTurn();
						boolean done = false;
						if(Game.checkWin()) {
							Alert alert = new Alert(Alert.AlertType.WARNING);
							alert.setTitle("Game Win");
							alert.setHeaderText("You have won!");
							ButtonType exitButton = new ButtonType("Exit", ButtonBar.ButtonData.OK_DONE);
					        alert.getButtonTypes().setAll(exitButton);
							alert.showAndWait();
							done = true;
						}
						if(Game.checkGameOver() && !done) {
							Alert alert = new Alert(Alert.AlertType.WARNING);
							ButtonType exitButton = new ButtonType("Exit", ButtonBar.ButtonData.OK_DONE);
					        alert.getButtonTypes().setAll(exitButton);
							alert.setTitle("Game Over");
							alert.setHeaderText("You have lost :(");
							alert.showAndWait();
							done = true;
						}
						if (done) {
							Platform.exit();
						}
					} catch (NotEnoughActionsException | InvalidTargetException e) {
						Alert alert = new Alert(Alert.AlertType.WARNING);
						alert.setTitle("Exception found");
						alert.setHeaderText(e.getMessage());
						alert.showAndWait();
						break;
					}
				case SPACE: try {
						selectedHero.attack();
						refreshMap();
						refreshHeroStats();
						refreshActionButtons();
						boolean done = false;
						if (Game.checkGameOver() && !done) {
							Alert alert = new Alert(Alert.AlertType.WARNING);
							alert.setTitle("Game Over");
							alert.setHeaderText("You have lost :(");
							ButtonType exitButton = new ButtonType("Exit", ButtonBar.ButtonData.OK_DONE);
					        alert.getButtonTypes().setAll(exitButton);
							alert.showAndWait();
							done = true;
						}
						if (done) {
							Platform.exit();
						}
					} catch (NotEnoughActionsException | InvalidTargetException e) {
						Alert alert = new Alert(Alert.AlertType.WARNING);
						alert.setTitle("Exception found");
						alert.setHeaderText(e.getMessage());
						alert.showAndWait();
						break;
					}
				case ENTER: try {
						selectedHero.cure();
						refreshMap();
						refreshHeroStats();
						refreshActionButtons();
						boolean done = false;
						if (Game.checkWin()) {
							Alert alert = new Alert(Alert.AlertType.WARNING);
							alert.setTitle("Game Win");
							alert.setHeaderText("You have won!");
							ButtonType exitButton = new ButtonType("Exit", ButtonBar.ButtonData.OK_DONE);
					        alert.getButtonTypes().setAll(exitButton);
							alert.showAndWait();
							done = true;
						}
						if(done)
							Platform.exit();
						break;
					} catch (NoAvailableResourcesException | InvalidTargetException | NotEnoughActionsException e) {
						Alert alert = new Alert(Alert.AlertType.WARNING);
						alert.setTitle("Exception found");
						alert.setHeaderText(e.getMessage());
						alert.showAndWait();
						break;
					}
				case S: try {
						selectedHero.move(Direction.LEFT);
						refreshMap();
						refreshHeroStats();
						refreshActionButtons();
						break;
						
					} catch (MovementException | NotEnoughActionsException e) {
						Alert alert = new Alert(Alert.AlertType.WARNING);
						alert.setTitle("Exception found");
						alert.setHeaderText(e.getMessage());
						alert.showAndWait();
						break;
					}
				case W: try {
						selectedHero.move(Direction.RIGHT);
						refreshMap();
						refreshHeroStats();
						refreshActionButtons();
						break;
					} catch (MovementException | NotEnoughActionsException e) {
						Alert alert = new Alert(Alert.AlertType.WARNING);
						alert.setTitle("Exception found");
						alert.setHeaderText(e.getMessage());
						alert.showAndWait();
						break;
					}
				case A: try {
						selectedHero.move(Direction.DOWN);
						refreshMap();
						refreshHeroStats();
						refreshActionButtons();
						break;
					} catch (MovementException | NotEnoughActionsException e) {
						Alert alert = new Alert(Alert.AlertType.WARNING);
						alert.setTitle("Exception found");
						alert.setHeaderText(e.getMessage());
						alert.showAndWait();
						break;
					}
				case D: try {
						selectedHero.move(Direction.UP);
						refreshMap();
						refreshHeroStats();
						refreshActionButtons();
						break;
					} catch (MovementException | NotEnoughActionsException e) {
						Alert alert = new Alert(Alert.AlertType.WARNING);
						alert.setTitle("Exception found");
						alert.setHeaderText(e.getMessage());
						alert.showAndWait();
						break;
					}
				case U: try {
						selectedHero.useSpecial();
						refreshMap();
						refreshHeroStats();
						refreshActionButtons();
						break;
						
					} catch (NoAvailableResourcesException | InvalidTargetException e) {
						Alert alert = new Alert(Alert.AlertType.WARNING);
						alert.setTitle("Exception found");
						alert.setHeaderText(e.getMessage());
						alert.showAndWait();
						break;
					}
				case P:
					try {
						selectedHero = Game.heroes.get(indexOfSelectedHero + 1);break;
					} catch (Exception e) {
						Alert alert = new Alert(Alert.AlertType.WARNING);
						alert.setTitle("Exception found");
						alert.setHeaderText(e.getMessage());
						alert.showAndWait();
						break;
					}
				case O:
					try {
						selectedHero = Game.heroes.get(indexOfSelectedHero - 1);break;
					} catch (Exception e) {
						Alert alert = new Alert(Alert.AlertType.WARNING);
						alert.setTitle("Exception found");
						alert.setHeaderText(e.getMessage());
						alert.showAndWait();
						break;
					}
				default:break;
			}

		}
		
		
	});
	}
	
	public static void actions(){
		helpButton.setOnMouseClicked(new EventHandler <Event>() {

			@Override
			public void handle(Event arg0) {
				Alert alert = new Alert(Alert.AlertType.INFORMATION);
				alert.setTitle("Help");
				alert.setHeaderText("Help");
				String content = "Should show help information for player";
				alert.setContentText(content);
				alert.showAndWait();
			}});
			
		endTurnButton.setOnMouseClicked(new EventHandler <Event>(){
			@Override
			public void handle(Event event) {
					try {
						Game.endTurn();
						boolean done = false; 
						if (Game.checkWin()) {
							Alert alert = new Alert(Alert.AlertType.WARNING);
							alert.setTitle("Game Win");
							alert.setHeaderText("You have won!");
							ButtonType exitButton = new ButtonType("Exit", ButtonBar.ButtonData.OK_DONE);
					        alert.getButtonTypes().setAll(exitButton);
							alert.showAndWait();
							done = true;
						}
						if (Game.checkGameOver() && !done) {
							Alert alert = new Alert(Alert.AlertType.WARNING);
							alert.setTitle("Game Over");
							alert.setHeaderText("You have lost :(");
							ButtonType exitButton = new ButtonType("Exit", ButtonBar.ButtonData.OK_DONE);
					        alert.getButtonTypes().setAll(exitButton);
							alert.showAndWait();
							done = true;
						}
						if (done) {
							Platform.exit();
						}
					} catch (NotEnoughActionsException | InvalidTargetException e) {
						Alert alert = new Alert(Alert.AlertType.WARNING);
						alert.setTitle("Exception found");
						alert.setHeaderText(e.getMessage());
						alert.showAndWait();
					}finally{
						refreshMap();
						refreshHeroStats();
						refreshActionButtons();
					}
				}
			});
		cureButton.setOnMouseClicked(new EventHandler <Event>(){
			@Override
			public void handle(Event event) {
				try {
					selectedHero.cure();
					refreshMap();
					refreshHeroStats();
					refreshActionButtons();
					boolean done = false;
					if (Game.checkWin()) {
						Alert alert = new Alert(Alert.AlertType.WARNING);
						alert.setTitle("Game Win");
						alert.setHeaderText("You have won!");
						ButtonType exitButton = new ButtonType("Exit", ButtonBar.ButtonData.OK_DONE);
				        alert.getButtonTypes().setAll(exitButton);
						alert.showAndWait();
						done = true;
					}
					if(done)
						Platform.exit();
					} catch (NoAvailableResourcesException | InvalidTargetException | NotEnoughActionsException e) {
					Alert alert = new Alert(Alert.AlertType.WARNING);
					alert.setTitle("Exception found");
					alert.setHeaderText(e.getMessage());
					alert.showAndWait();
					}
				}
			});
		useSpecialButton.setOnMouseClicked(new EventHandler <Event>(){
			@Override
			public void handle(Event event) {
				try {
					selectedHero.useSpecial();
					refreshMap();
					refreshHeroStats();
					refreshActionButtons();			
				} catch (NoAvailableResourcesException | InvalidTargetException e) {
					Alert alert = new Alert(Alert.AlertType.WARNING);
					alert.setTitle("Exception found");
					alert.setHeaderText(e.getMessage());
					alert.showAndWait();
					}
				}
			});
		attackButton.setOnMouseClicked(new EventHandler <Event>(){
			@Override
			public void handle(Event event) {
					try {
						selectedHero.attack();
						refreshMap();
						refreshHeroStats();
						refreshActionButtons();
						boolean done = false;
						if (Game.checkGameOver() && !done) {
							Alert alert = new Alert(Alert.AlertType.WARNING);
							alert.setTitle("Game Over");
							alert.setHeaderText("You have lost :(");
							ButtonType exitButton = new ButtonType("Exit", ButtonBar.ButtonData.OK_DONE);
					        alert.getButtonTypes().setAll(exitButton);
							alert.showAndWait();
							done = true;
						}
						if (done) {
							Platform.exit();
						}
					} catch (NotEnoughActionsException | InvalidTargetException e) {
						Alert alert = new Alert(Alert.AlertType.WARNING);
						alert.setTitle("Exception found");
						alert.setHeaderText(e.getMessage());
						alert.showAndWait();
					}
				}
			});
		left.setOnMouseClicked(new EventHandler <Event>(){
			@Override
			public void handle(Event event) {
					try {
						selectedHero.move(Direction.DOWN);
						refreshMap();
						refreshHeroStats();
						refreshActionButtons();
					} catch (MovementException | NotEnoughActionsException e) {
						Alert alert = new Alert(Alert.AlertType.WARNING);
						alert.setTitle("Exception found");
						alert.setHeaderText(e.getMessage());
						alert.showAndWait();
					}
				}
			});
		right.setOnMouseClicked(new EventHandler <Event>(){
			@Override
			public void handle(Event event) {
					try {
						selectedHero.move(Direction.UP);
						refreshMap();
						refreshHeroStats();
						refreshActionButtons();
					} catch (MovementException | NotEnoughActionsException e) {
						Alert alert = new Alert(Alert.AlertType.WARNING);
						alert.setTitle("Exception found");
						alert.setHeaderText(e.getMessage());
						alert.showAndWait();
					}
				}
			});
		up.setOnMouseClicked(new EventHandler <Event>(){
			@Override
			public void handle(Event event) {
					try {
						selectedHero.move(Direction.RIGHT);
						refreshMap();
						refreshHeroStats();
						refreshActionButtons();
					} catch (MovementException | NotEnoughActionsException e) {
						Alert alert = new Alert(Alert.AlertType.WARNING);
						alert.setTitle("Exception found");
						alert.setHeaderText(e.getMessage());
						alert.showAndWait();
					}
				}
			});
		down.setOnMouseClicked(new EventHandler <Event>(){
			@Override
			public void handle(Event event) {
					try {
						selectedHero.move(Direction.LEFT);
						refreshMap();
						refreshHeroStats();
						refreshActionButtons();
					} catch (MovementException | NotEnoughActionsException e) {
						Alert alert = new Alert(Alert.AlertType.WARNING);
						alert.setTitle("Exception found");
						alert.setHeaderText(e.getMessage());
						alert.showAndWait();
					}
				}
			});
	}
	
	public static void refreshHeroStats(){
		heroes.getChildren().clear();
		for(int i = 0; i < Game.heroes.size(); i++) {
			HBox cont = new HBox();
			VBox eachHero = new VBox();
			cont.setPadding(new Insets(10,10,10,10));
			cont.setStyle("-fx-background-color: black;");
			if(Game.heroes.get(i) == selectedHero) {
				cont.setStyle(cont.getStyle()+"-fx-border-color: white; -fx-border-width: 3px;");
			}
			Label name = new Label(Game.heroes.get(i).getName() + "\nMax Actions: " + Game.heroes.get(i).getMaxActions() + "\nDamage: " + Game.heroes.get(i).getAttackDmg() + "\nRemaining actions: " + selectedHero.getActionsAvailable());
			name.setTextFill(Paint.valueOf("white"));
			name.setFont(Font.font("Courier New", FontWeight.BOLD, 14));
			Image remainImg;
			if(Game.heroes.get(i) instanceof Fighter)
				remainImg = new Image("deadpool.png");
			else if(Game.heroes.get(i) instanceof Medic)
				remainImg = new Image("medic.png");
			else 
				remainImg = new Image("explorer.png");
			ImageView remainImgView = new ImageView(remainImg);
			remainImgView.setFitHeight(50);
			remainImgView.setFitWidth(50);

			HBox vaccines = new HBox();
			vaccines.setBackground(new Background(new BackgroundFill(Color.WHITE, null, null)));
			HBox supplies = new HBox();
			supplies.setBackground(new Background(new BackgroundFill(Color.GOLD, null, null)));
			vaccines.setSpacing(3);
			supplies.setSpacing(3);
			for(int j = 0; j < Game.heroes.get(i).getVaccineInventory().size(); j++) {
				Image syr = new Image("syringe.png");
				ImageView img = new ImageView(syr);
				img.setFitHeight(20);
				img.setFitWidth(20);

				vaccines.getChildren().addAll(img);
			}
			for(int j = 0; j < Game.heroes.get(i).getSupplyInventory().size(); j++) {
				Image sup = new Image("supply.png");
				ImageView img = new ImageView(sup);
				img.setFitHeight(20);
				img.setFitWidth(20);

				supplies.getChildren().addAll(img);
			}
			int j=i;
	         cont.setOnMouseClicked(new EventHandler <Event>(){
	 			@Override
	 			public void handle(Event event) {
	 				selectedHero = Game.heroes.get(j);
	 				refreshHeroStats();
	 				refreshMap();
	 				}
	 			});
	        HBox health = new HBox();
	        Label healthNote = new Label("  " + Game.heroes.get(i).getCurrentHp() + "HP");
	        healthNote.setTextFill(Paint.valueOf("white"));
			healthNote.setFont(Font.font("Courier New", FontWeight.BOLD, 14));
	        ProgressBar healthPB = new ProgressBar((float)(Game.heroes.get(i).getCurrentHp()/(float)Game.heroes.get(i).getMaxHp()));
	        health.getChildren().addAll(healthPB,healthNote);
	        Region spacer = new Region();
	        HBox.setHgrow(spacer, Priority.ALWAYS);
			eachHero.getChildren().addAll(name,vaccines,supplies,health);
			cont.getChildren().addAll(eachHero,spacer,remainImgView);
			cont.setTranslateY(200);
			heroes.getChildren().addAll(cont);
		}	
	}
	public static boolean isAdj(Point p1,Point p2){
		if(Math.abs(p1.x-p2.x)<=1&&Math.abs(p1.y-p2.y)<=1){
			return true;
		}
		return false;
	}
	
	public static void refreshActionButtons(){
		if(selectedHero != null && selectedHero.getSupplyInventory().size() > 0) {
			useSpecialButton.setBackground(new Background(new BackgroundFill(Color.GOLD, null, null)));
		} else {
			useSpecialButton.setBackground(null);
		}
		if(selectedHero != null && selectedHero.getTarget() instanceof Zombie) {
			attackButton.setStyle("-fx-background-color: #FFFFFF;");
			if(selectedHero.getVaccineInventory().size() > 0) {
				cureButton.setStyle("-fx-background-color: #FFFFFF;");
			} else {
				cureButton.setBackground(null);
			}
		} else {
			attackButton.setBackground(null);
			cureButton.setBackground(null);
		}
	}
	public static void refreshMap(){
		map.getChildren().clear();
		for(int i = 14; i >= 0; i--) {
			for(int j = 14; j >= 0; j--) {
				if(!Game.map[i][j].isVisible()) {
					MapCell notVisibleCell = new MapCell("empty.jpg");
					map.add(notVisibleCell, i, 14-j);
				} else {
					if(Game.map[i][j] instanceof CharacterCell) {
						MapCell characterCellButton;
						String charImg = null;
						Character cellCharacter = ((CharacterCell)Game.map[i][j]).getCharacter();
						if(cellCharacter!=null){
							if(cellCharacter instanceof Zombie)
								charImg = "zomb.png";
							else if(cellCharacter instanceof Fighter)
								charImg = "deadpool.png";
							else if(cellCharacter instanceof Medic)
								charImg = "medic.png";
							else if(cellCharacter instanceof Explorer)
								charImg = "explorer.png";
							characterCellButton = new MapCell(charImg);
							if(cellCharacter==selectedHero.getTarget()){
								characterCellButton.setPadding(Insets.EMPTY);
								characterCellButton.setStyle("-fx-background-color: #0000FF;");
							}
							if (cellCharacter == selectedHero) {
								characterCellButton.setPadding(new Insets(0));
								characterCellButton.setStyle("-fx-background-color: #FFFFFF;");
							} else {
								characterCellButton.setBackground(null);
							}
							characterCellButton.setOnMouseClicked(new EventHandler <Event>(){
								@Override
								public void handle(Event event) {
									selectedHero.setTarget(cellCharacter);
									refreshMap();
									refreshActionButtons();
								}
							});
							if(!(cellCharacter instanceof Zombie))
								map.add(characterCellButton, i, 14-j);
							else {
								ProgressBar zombieHealth = new ProgressBar(((float)((CharacterCell)Game.map[i][j]).getCharacter().getCurrentHp())/((float)((CharacterCell)Game.map[i][j]).getCharacter().getMaxHp()));
								zombieHealth.setTranslateY(20);
								zombieHealth.setMaxHeight(10);
								StackPane zombieAll = new StackPane();
								zombieAll.getChildren().addAll(characterCellButton,zombieHealth);
								map.add(zombieAll, i, 14-j);
							}
						}else {
							MapCell emptyCellButton = new MapCell("light grass.png");
							int x = i;
							int y = j;
							emptyCellButton.setOnMouseClicked(new EventHandler <Event>(){
								@Override
								public void handle(Event event){
									if(isAdj(selectedHero.getLocation(),new Point(x,y))){
										System.out.println("make button available to move to " + x + " " + y);
									}
								}
							});
							map.add(emptyCellButton, i, 14-j);
						}
					}else {
						MapCell collectibleCell = new MapCell("right.png");
						if(Game.map[i][j] instanceof TrapCell) {
							collectibleCell = new MapCell("light grass.png");
						} else if(Game.map[i][j] instanceof CollectibleCell) {
							if(((CollectibleCell)Game.map[i][j]).getCollectible() instanceof Vaccine) {
								collectibleCell = new MapCell("syringe.png");
								collectibleCell.setBorder(null);
								ScaleTransition cTransition = new ScaleTransition(Duration.seconds(1.5),collectibleCell);
								cTransition.setToX(1.35);
								cTransition.setToY(1.35);
								cTransition.setCycleCount((int) 100f);
								cTransition.setAutoReverse(true);
								cTransition.play();

							} else {
								collectibleCell = new MapCell("supply.png");
								collectibleCell.setBorder(null);
								ScaleTransition cTransition = new ScaleTransition(Duration.seconds(1.5),collectibleCell);
								cTransition.setToX(1.5);
								cTransition.setToY(1.5);
								cTransition.setCycleCount((int) 100f);
								cTransition.setAutoReverse(true);
								cTransition.play();
							}
						}
						map.add(collectibleCell, i, 14-j);
					}
				}
			}
		}
	}
}
