package application;
	
import java.io.IOException;

import engine.Game;
import javafx.application.Application;
//import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.geometry.Side;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.TextAlignment;
import javafx.stage.Screen;
import javafx.stage.Stage;
import model.characters.Fighter;
import model.characters.Hero;
import model.characters.Medic;

public class Main extends Application {
	static Hero selected = null;
	public static Button sButton = null;
	public static Stage primaryStage;
	public static Scene s;
	@Override
	public void init() throws IOException {
		Game.loadHeroes("Heroes.csv");
	}
	public void start(Stage primaryStage) {
		VBox root = new VBox(); //layout of first page
		
		root.setStyle("-fx-background-color: #FFFFFF; ");
		root.setAlignment(Pos.CENTER);
		
		ImageView heading = new ImageView(new Image("title1.png"));
		heading.setTranslateY(-20);
		
		HBox selectHeroes = new HBox(); //The horizontal list of heroes
		selectHeroes.setPadding(new Insets(20,20,20,20));
		selectHeroes.setSpacing(10);
		selectHeroes.setMinHeight(150);
		selectHeroes.setAlignment(Pos.BASELINE_CENTER);
		selectHeroes.setStyle("-fx-background-color: #0b2239; ");

		Label noSelectMsg = new Label("");;
		for(int i = 0; i < Game.availableHeroes.size(); i++) {
			int index = i;
			VBox eachHero = new VBox();
			eachHero.setSpacing(10);
			eachHero.setStyle("-fx-background-color: #D3D3D3; ");
			eachHero.setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, CornerRadii.EMPTY, BorderWidths.DEFAULT)));
			eachHero.setAlignment(Pos.CENTER);
			eachHero.setPadding(new Insets(10,10,10,10));
			eachHero.setMinWidth(100);
			Label eachDetail = new Label("");
			noSelectMsg = new Label("");
			eachDetail.setFont(Font.font(16));
			Button b1 = new Button(Game.availableHeroes.get(index).getName());
			b1.setStyle("-fx-text-fill: white;-fx-background-color: #0b2239;");
			b1.setSkin(new MyButtonSkin(b1));
			b1.setWrapText(true);
			b1.setPadding(new Insets(2,2,2,2));
			b1.setFont(Font.font("Courier New", FontWeight.BOLD, 16));
			b1.setAlignment(Pos.BASELINE_CENTER);
			b1.setOnMouseClicked(new EventHandler <Event>(){
				@Override
				public void handle(Event event) {
					selected = Game.availableHeroes.get(index);
					if(sButton != null) {
						sButton.setStyle("-fx-text-fill: white;-fx-background-color: #0b2239;");
					}
					sButton = b1;
					b1.setStyle("-fx-background-color: #00ff00; ");
				}
				});
			String details = "Damage: " + Game.availableHeroes.get(index).getAttackDmg() + "\n";
			details += "HP: " + Game.availableHeroes.get(index).getMaxHp() + "\n" 
					+ "Actions: " + Game.availableHeroes.get(index).getMaxActions() + "\n";
			if(Game.availableHeroes.get(index) instanceof Fighter) {
				details += "Fighter";
			} else if(Game.availableHeroes.get(index) instanceof Medic) {
				details += "Medic";
			} else {
				details += "Explorer";
			}
			eachDetail.setTextFill(Color.WHITE);
			Image remainImg;
			if(Game.availableHeroes.get(i) instanceof Fighter)
				remainImg = new Image("deadpool.png");
			else if(Game.availableHeroes.get(i) instanceof Medic)
				remainImg = new Image("medic.png");
			else 
				remainImg = new Image("explorer.png");
			ImageView remainImgView = new ImageView(remainImg);
			remainImgView.setFitHeight(70);
			remainImgView.setFitWidth(70);
			eachDetail = new Label(details);
			eachDetail.setFont(Font.font("Courier New", FontWeight.BOLD, 14));
			eachDetail.setWrapText(true);
			eachDetail.setTextAlignment(TextAlignment.CENTER);
			eachHero.getChildren().addAll(b1, remainImgView, eachDetail);
			selectHeroes.getChildren().addAll(eachHero);
		}
		
		Label finalNoSelectMsg = noSelectMsg;
		ImageButton startGame = new ImageButton("start.png",100,120,0);
		
		// Set the fullScreenExitHint to an empty string
        primaryStage.setFullScreenExitHint("");
        // Get the primary screen
        Screen screen = Screen.getPrimary();

        // Get the visual bounds of the screen
        Rectangle2D bounds = screen.getVisualBounds();

        // Retrieve the screen width and height
        double screenWidth = bounds.getWidth();
        double screenHeight = bounds.getHeight();
        primaryStage.setX(0);
        primaryStage.setY(0);

        // Add an event handler to prevent the stage from closing on fullscreen exit;
		startGame.setOnMouseClicked(new EventHandler <Event>(){
			@Override
			public void handle(Event event) {
				if(selected != null) {
					System.out.println(selected);
					Game.startGame(selected);
					Play.start(selected);
					primaryStage.setScene(Play.play);
					//primaryStage.setFullScreen(true);
				}
				else {
					finalNoSelectMsg.setText("No Hero Selected");
					finalNoSelectMsg.setBackground(new Background(new BackgroundFill(Color.WHITE, null, null)));
					finalNoSelectMsg.setPadding(new Insets(5,5,5,5));
					finalNoSelectMsg.setFont(Font.font("Courier New", FontWeight.BOLD,30));
					finalNoSelectMsg.setBorder(new Border(new BorderStroke(Color.RED, BorderStrokeStyle.SOLID, CornerRadii.EMPTY, BorderWidths.DEFAULT)));

				}
			}
		});
		
		root.getChildren().addAll(heading,selectHeroes,startGame,noSelectMsg);
		
		s = new Scene(root,screenWidth,screenHeight);
		primaryStage.setTitle("The Last Of Us - Legacy");
		primaryStage.getIcons().add(new Image("title1.png"));
		primaryStage.setScene(s);
		primaryStage.show();
	}
	
	public static void main(String[] args) {
		launch(args);
	}
	
	public void stop() {
		
	}
	
}

