package model.world;

import model.collectibles.*;

public class MilitaryBase extends Building {
	
	public MilitaryBase() {
		super(new Supply());
	}
}
