package application;
	
import java.io.IOException;

import application.Play;
import engine.Game;
import javafx.application.Application;
//import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.geometry.Side;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.TextAlignment;
import javafx.stage.Screen;
import javafx.stage.Stage;
import model.characters.Fighter;
import model.characters.Hero;
import model.characters.Medic;
import javafx.scene.control.ChoiceBox;

public class Main extends Application {
	static Hero selected = null;
	@Override
	public void init() throws IOException {
		Game.loadHeroes("Heroes.csv");
	}
	public void start(Stage primaryStage) {
		VBox root = new VBox(); //layout of first page
		
		root.setBackground(new Background(new BackgroundImage( new Image("bg.jpg"),
				BackgroundRepeat.REPEAT, 
				BackgroundRepeat.NO_REPEAT, 
				new BackgroundPosition(Side.LEFT, 0, true, Side.BOTTOM, 0, true),
				new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, true)
                )));
		root.setAlignment(Pos.CENTER);

		Label heading = new Label("The Last Of Us - Legacy"); //Title of Game
		heading.setFont(Font.font(70));
		heading.setOpacity(1);
		heading.setTextAlignment(TextAlignment.CENTER);
		heading.setTextFill(Color.WHITE);
		heading.setBackground(new Background(new BackgroundFill(Color.DARKGREEN, null, null)));
		
		HBox selectHeroes = new HBox(); //The horizontal list of heroes
		selectHeroes.setSpacing(20);
		selectHeroes.setAlignment(Pos.BASELINE_CENTER);
		selectHeroes.setBackground(new Background(new BackgroundFill(Color.BISQUE, null, null)));
		
		Label noSelectMsg = new Label("");;
		for(int i = 0; i < Game.availableHeroes.size(); i++) {
			int index = i;
			VBox eachHero = new VBox();
			Label eachDetail = new Label("");
			noSelectMsg = new Label("");
			eachDetail.setFont(Font.font(20));
			Button b1 = new Button(Game.availableHeroes.get(index).getName());
			b1.setAlignment(Pos.BASELINE_CENTER);
			b1.setOnMouseClicked(new EventHandler <Event>(){
				@Override
				public void handle(Event event) {
					selected = Game.availableHeroes.get(index);
				}
				});
			String details = "Damage: " + Game.availableHeroes.get(index).getAttackDmg() + "\n";
			details += "HP: " + Game.availableHeroes.get(index).getMaxHp() + "\n";
			if(Game.availableHeroes.get(index) instanceof Fighter) {
				details += "Fighter";
			} else if(Game.availableHeroes.get(index) instanceof Medic) {
				details += "Medic";
			} else {
				details += "Explorer";
			}
			eachDetail = new Label(details);
			eachDetail.setTextAlignment(TextAlignment.CENTER);
			eachHero.getChildren().addAll(b1, eachDetail);
			selectHeroes.getChildren().addAll(eachHero);
		}
		
		Label finalNoSelectMsg = noSelectMsg;
		Button startGame = new Button("Start Game");
		startGame.setOnMouseClicked(new EventHandler <Event>(){
			@Override
			public void handle(Event event) {
				if(selected != null) {
					Game.startGame(selected);
					Play.start(selected);
					primaryStage.setScene(Play.play);
				}
				else 
					finalNoSelectMsg.setText("No Hero Selected");
			}
		});
		
		root.getChildren().addAll(heading,selectHeroes,startGame,noSelectMsg);
		Screen screen = Screen.getPrimary();
        Rectangle2D bounds = screen.getVisualBounds();
        
        // Create the scene with the screen dimensions
		Scene s = new Scene(root, bounds.getWidth(), bounds.getHeight());
		primaryStage.setTitle("The Last Of Us - Legacy");
		//primaryStage.getIcons().add(new Image("1.png"));
		primaryStage.setScene(s);
		primaryStage.show();
	}
	
	public static void main(String[] args) {
		launch(args);
	}
	
	public void stop() {
		
	}
	
}

