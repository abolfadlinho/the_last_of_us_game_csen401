package application;


import java.io.IOException;
import application.Play;
import engine.Game;
import exceptions.InvalidTargetException;
import exceptions.MovementException;
import exceptions.NoAvailableResourcesException;
import exceptions.NotEnoughActionsException;
import javafx.application.Application;
//import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Side;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import model.characters.*;
import model.characters.Character;
import model.collectibles.*;
import model.world.*;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.control.ProgressBar;


public class Play {
	public static Scene play;
	public static Hero selectedHero = Main.selected;
	public static int indexOfSelectedHero = 0;
	
	public static void shit() {
		BorderPane root = new BorderPane();
		HBox heroes = new HBox();
		GridPane map = new GridPane();
		root.setCenter(map);
		root.setTop(heroes);
		for(int i = 0; i < Game.heroes.size(); i++) {
			VBox eachHero = new VBox();
			if(Game.heroes.get(i) == selectedHero) {
				eachHero.setBackground(new Background(new BackgroundFill(Color.LIGHTBLUE, null, null)));
			}
			Label eachHeroLabel = new Label( (i+1) + "  " 
					+ Game.heroes.get(i).getName() + "\n" 
					+ "Maximum Actions per turn: " + Game.heroes.get(i).getMaxActions() 
					+ "\n" + "Damage: " + Game.heroes.get(i).getAttackDmg());
			Image remainImg;
			if(Game.heroes.get(i) instanceof Fighter)
				remainImg = new Image("C://Users//DELL//Desktop/fighter.jpg");
			else if(Game.heroes.get(i) instanceof Medic)
				remainImg = new Image("C://Users//DELL//Desktop/medic.jpg");
			else 
				remainImg = new Image("C://Users//DELL//Desktop/explorer.png");
			ImageView remainImgView = new ImageView(remainImg);
			remainImgView.setFitHeight(20);
			remainImgView.setFitWidth(20);
			eachHeroLabel.setTextAlignment(TextAlignment.CENTER);
			HBox vaccines = new HBox();
			HBox supplies = new HBox();
			vaccines.setSpacing(3);
			supplies.setSpacing(3);
			ProgressBar health = new ProgressBar(Game.heroes.get(i).getCurrentHp()/Game.heroes.get(i).getMaxHp());
			for(int j = 0; j < Game.heroes.get(i).getVaccineInventory().size() + 4; j++) {
				Image syr = new Image("C://Users//DELL//Desktop/syringe.png");
				ImageView img = new ImageView(syr);
				img.setFitHeight(20);
				img.setFitWidth(20);

				vaccines.getChildren().addAll(img);
			}
			for(int j = 0; j < Game.heroes.get(i).getSupplyInventory().size() + 3; j++) {
				Image sup = new Image("C://Users//DELL//Desktop/supply.jpg");
				ImageView img = new ImageView(sup);
				img.setFitHeight(20);
				img.setFitWidth(20);

				supplies.getChildren().addAll(img);
			}
			eachHero.getChildren().addAll(eachHeroLabel,remainImgView,vaccines,supplies,health);
			heroes.getChildren().addAll(eachHero);
		}	
		//map.setHgap(45);
		//map.setVgap(12);
		//map.setPadding(new Insets(20, 20, 20, 20));
		for(int i = 0; i < 15; i++) {
			for(int j = 0; j < 15; j++) {
				if(!Game.map[i][j].isVisible()) {
					Image unknown = new Image("C://Users//DELL//Desktop/notVisible.png");
					ImageView unknownView = new ImageView(unknown);
					unknownView.setFitHeight(20);
					unknownView.setFitWidth(20);
					map.add(unknownView, i, j);
				} else {
					if(Game.map[i][j] instanceof CharacterCell) {
						VBox buttonWithName = new VBox();
						Button characterCellButton = new Button();
						Image charImg;
						Character cellCharacter = ((CharacterCell)Game.map[i][j]).getCharacter();
						boolean isEmpty = false;
						if(cellCharacter instanceof Zombie)
							charImg = new Image("C://Users//DELL//Desktop/zombie.webp");
						else {
							if(cellCharacter instanceof Fighter)
								charImg = new Image("C://Users//DELL//Desktop/fighter.jpg");
							else if(cellCharacter instanceof Medic)
								charImg = new Image("C://Users//DELL//Desktop/medic.jpg");
							else if(cellCharacter instanceof Explorer)
								charImg = new Image("C://Users//DELL//Desktop/explorer.png");
							else {
								isEmpty = true;
								charImg = new Image("C://Users//DELL//Desktop/empty.jpg");
								ImageView emptyView = new ImageView(charImg);
								emptyView.setFitHeight(20);
								emptyView.setFitWidth(20);
								map.add(emptyView, i, j);
							}
								
						}
						characterCellButton.setOnMouseClicked(new EventHandler <Event>(){
							@Override
							public void handle(Event event) {
								selectedHero.setTarget(cellCharacter);
							}
							});
						if(!isEmpty) {
							Label characterName = new Label(cellCharacter.getName());
							ImageView charView = new ImageView(charImg);
							charView.setFitHeight(20);
							charView.setFitWidth(20);
							characterCellButton.setGraphic(charView);
							characterCellButton.setPrefSize(20, 20);
							buttonWithName.getChildren().addAll(characterName,characterCellButton);
							if(cellCharacter instanceof Hero) {
								Label actionsAvailable = new Label(((Hero)cellCharacter).getActionsAvailable() + " actions left");
								buttonWithName.getChildren().addAll(actionsAvailable);
							}
							map.add(buttonWithName, i, j);
						}
					} else {
						if(Game.map[i][j] instanceof TrapCell) {
							ImageView emptyView = new ImageView(new Image("C://Users//DELL//Desktop/empty.jpg"));
							emptyView.setFitHeight(20);
							emptyView.setFitWidth(20);
							map.add(emptyView, i, j);
						} else if(Game.map[i][j] instanceof CollectibleCell) {
							if(((CollectibleCell)Game.map[i][j]).getCollectible() instanceof Vaccine) {
								ImageView vaccineView = new ImageView(new Image("C://Users//DELL//Desktop/syringe.png"));
								vaccineView.setFitHeight(20);
								vaccineView.setFitWidth(20);
								map.add(vaccineView, i, j);
							} else {
								ImageView supplyView = new ImageView(new Image("C://Users//DELL//Desktop/supply.jpg"));
								supplyView.setFitHeight(20);
								supplyView.setFitWidth(20);
								map.add(supplyView, i, j);
							}
						}
					}
				}
			}
		}
		Label messages = new Label("");
		root.setBottom(messages);
		play = new Scene(root,1000,600);
		
		play.setOnKeyPressed(new EventHandler<KeyEvent>(){
			
			@Override
			public void handle(KeyEvent event) {
				switch(event.getCode()) {
					case X: try {
							Game.endTurn();messages.setText("");break;
						} catch (NotEnoughActionsException e) {
							messages.setText(e.getMessage());break;
						} catch (InvalidTargetException e) {
							messages.setText(e.getMessage());break;
						}
					case SPACE: try {
							selectedHero.attack();messages.setText("");break;
						} catch (NotEnoughActionsException e) {
							messages.setText(e.getMessage());break;
						} catch (InvalidTargetException e) {
							messages.setText(e.getMessage());break;
						}
					case ENTER: try {
							selectedHero.cure();messages.setText("");break;
						} catch (NoAvailableResourcesException e) {
							messages.setText(e.getMessage());break;
						} catch (InvalidTargetException e) {
							messages.setText(e.getMessage());break;
						} catch (NotEnoughActionsException e) {
							messages.setText(e.getMessage());break;
						}
					case S: try {
							selectedHero.move(Direction.UP);messages.setText("");break;
						} catch (MovementException e) {
							messages.setText(e.getMessage());break;
						} catch (NotEnoughActionsException e) {
							messages.setText(e.getMessage());break;
					}case W: try {
							selectedHero.move(Direction.DOWN);messages.setText("");break;
						} catch (MovementException e) {
							messages.setText(e.getMessage());break;
						} catch (NotEnoughActionsException e) {
							messages.setText(e.getMessage());break;
					}case A: try {
							selectedHero.move(Direction.LEFT);messages.setText("");break;
						} catch (MovementException e) {
							messages.setText(e.getMessage());break;
						} catch (NotEnoughActionsException e) {
							messages.setText(e.getMessage());break;
					}case D: try {
							selectedHero.move(Direction.RIGHT);messages.setText("");break;
						} catch (MovementException e) {
							messages.setText(e.getMessage());break;
						} catch (NotEnoughActionsException e) {
							messages.setText(e.getMessage());break;
					}
					case U: try {
							selectedHero.useSpecial();messages.setText("");break;
						} catch (NoAvailableResourcesException e) {
							messages.setText(e.getMessage());break;
						} catch (InvalidTargetException e) {
							messages.setText(e.getMessage());break;
						}
					case P:
						try {
							selectedHero = Game.heroes.get(indexOfSelectedHero + 1);break;
						} catch (Exception e) {
							System.out.print("error P");
							messages.setText("No heroes on right");break;
						}
					case O:
						try {
							selectedHero = Game.heroes.get(indexOfSelectedHero - 1);break;
						} catch (Exception e) {
							System.out.print("error O");
							messages.setText("No heroes on left");break;
						}
					default:break;
				}

			}
			
		});
	}
	
	public static BorderPane reloadPane() {
		BorderPane root = new BorderPane();
		HBox heroes = new HBox();
		GridPane map = new GridPane();
		root.setCenter(map);
		root.setTop(heroes);
		for(int i = 0; i < Game.heroes.size(); i++) {
			VBox eachHero = new VBox();
			if(Game.heroes.get(i) == selectedHero) {
				eachHero.setBackground(new Background(new BackgroundFill(Color.LIGHTBLUE, null, null)));
			}
			Label eachHeroLabel = new Label( (i+1) + "  " 
					+ Game.heroes.get(i).getName() + "\n" 
					+ "Maximum Actions per turn: " + Game.heroes.get(i).getMaxActions() 
					+ "\n" + "Damage: " + Game.heroes.get(i).getAttackDmg());
			Image remainImg;
			if(Game.heroes.get(i) instanceof Fighter)
				remainImg = new Image("C://Users//DELL//Desktop/fighter.jpg");
			else if(Game.heroes.get(i) instanceof Medic)
				remainImg = new Image("C://Users//DELL//Desktop/medic.jpg");
			else 
				remainImg = new Image("C://Users//DELL//Desktop/explorer.png");
			ImageView remainImgView = new ImageView(remainImg);
			remainImgView.setFitHeight(20);
			remainImgView.setFitWidth(20);
			eachHeroLabel.setTextAlignment(TextAlignment.CENTER);
			HBox vaccines = new HBox();
			HBox supplies = new HBox();
			vaccines.setSpacing(3);
			supplies.setSpacing(3);
			ProgressBar health = new ProgressBar(Game.heroes.get(i).getCurrentHp()/Game.heroes.get(i).getMaxHp());
			for(int j = 0; j < Game.heroes.get(i).getVaccineInventory().size() + 4; j++) {
				Image syr = new Image("C://Users//DELL//Desktop/syringe.png");
				ImageView img = new ImageView(syr);
				img.setFitHeight(20);
				img.setFitWidth(20);

				vaccines.getChildren().addAll(img);
			}
			for(int j = 0; j < Game.heroes.get(i).getSupplyInventory().size() + 3; j++) {
				Image sup = new Image("C://Users//DELL//Desktop/supply.jpg");
				ImageView img = new ImageView(sup);
				img.setFitHeight(20);
				img.setFitWidth(20);

				supplies.getChildren().addAll(img);
			}
			eachHero.getChildren().addAll(eachHeroLabel,remainImgView,vaccines,supplies,health);
			heroes.getChildren().addAll(eachHero);
		}	
		//map.setHgap(45);
		//map.setVgap(12);
		//map.setPadding(new Insets(20, 20, 20, 20));
		for(int i = 0; i < 15; i++) {
			for(int j = 0; j < 15; j++) {
				if(!Game.map[i][j].isVisible()) {
					Image unknown = new Image("C://Users//DELL//Desktop/notVisible.png");
					ImageView unknownView = new ImageView(unknown);
					unknownView.setFitHeight(20);
					unknownView.setFitWidth(20);
					map.add(unknownView, i, j);
				} else {
					if(Game.map[i][j] instanceof CharacterCell) {
						VBox buttonWithName = new VBox();
						Button characterCellButton = new Button();
						Image charImg;
						Character cellCharacter = ((CharacterCell)Game.map[i][j]).getCharacter();
						boolean isEmpty = false;
						if(cellCharacter instanceof Zombie)
							charImg = new Image("C://Users//DELL//Desktop/zombie.webp");
						else {
							if(cellCharacter instanceof Fighter)
								charImg = new Image("C://Users//DELL//Desktop/fighter.jpg");
							else if(cellCharacter instanceof Medic)
								charImg = new Image("C://Users//DELL//Desktop/medic.jpg");
							else if(cellCharacter instanceof Explorer)
								charImg = new Image("C://Users//DELL//Desktop/explorer.png");
							else {
								isEmpty = true;
								charImg = new Image("C://Users//DELL//Desktop/empty.jpg");
								ImageView emptyView = new ImageView(charImg);
								emptyView.setFitHeight(20);
								emptyView.setFitWidth(20);
								map.add(emptyView, i, j);
							}
								
						}
						characterCellButton.setOnMouseClicked(new EventHandler <Event>(){
							@Override
							public void handle(Event event) {
								selectedHero.setTarget(cellCharacter);
							}
							});
						if(!isEmpty) {
							Label characterName = new Label(cellCharacter.getName());
							ImageView charView = new ImageView(charImg);
							charView.setFitHeight(20);
							charView.setFitWidth(20);
							characterCellButton.setGraphic(charView);
							characterCellButton.setPrefSize(20, 20);
							buttonWithName.getChildren().addAll(characterName,characterCellButton);
							if(cellCharacter instanceof Hero) {
								Label actionsAvailable = new Label(((Hero)cellCharacter).getActionsAvailable() + " actions left");
								buttonWithName.getChildren().addAll(actionsAvailable);
							}
							map.add(buttonWithName, i, j);
						}
					} else {
						if(Game.map[i][j] instanceof TrapCell) {
							ImageView emptyView = new ImageView(new Image("C://Users//DELL//Desktop/empty.jpg"));
							emptyView.setFitHeight(20);
							emptyView.setFitWidth(20);
							map.add(emptyView, i, j);
						} else if(Game.map[i][j] instanceof CollectibleCell) {
							if(((CollectibleCell)Game.map[i][j]).getCollectible() instanceof Vaccine) {
								ImageView vaccineView = new ImageView(new Image("C://Users//DELL//Desktop/syringe.png"));
								vaccineView.setFitHeight(20);
								vaccineView.setFitWidth(20);
								map.add(vaccineView, i, j);
							} else {
								ImageView supplyView = new ImageView(new Image("C://Users//DELL//Desktop/supply.jpg"));
								supplyView.setFitHeight(20);
								supplyView.setFitWidth(20);
								map.add(supplyView, i, j);
							}
						}
					}
				}
			}
		}
		return root;
	}
	public static GridPane reloadMap() {
		GridPane map = new GridPane();
		for(int i = 0; i < 15; i++) {
			for(int j = 0; j < 15; j++) {
				if(!Game.map[i][j].isVisible()) {
					Image unknown = new Image("C://Users//DELL//Desktop/notVisible.png");
					ImageView unknownView = new ImageView(unknown);
					unknownView.setFitHeight(20);
					unknownView.setFitWidth(20);
					map.add(unknownView, i, j);
				} else {
					if(Game.map[i][j] instanceof CharacterCell) {
						VBox buttonWithName = new VBox();
						Button characterCellButton = new Button();
						Image charImg;
						Character cellCharacter = ((CharacterCell)Game.map[i][j]).getCharacter();
						boolean isEmpty = false;
						if(cellCharacter instanceof Zombie)
							charImg = new Image("C://Users//DELL//Desktop/zombie.webp");
						else {
							if(cellCharacter instanceof Fighter)
								charImg = new Image("C://Users//DELL//Desktop/fighter.jpg");
							else if(cellCharacter instanceof Medic)
								charImg = new Image("C://Users//DELL//Desktop/medic.jpg");
							else if(cellCharacter instanceof Explorer)
								charImg = new Image("C://Users//DELL//Desktop/explorer.png");
							else {
								isEmpty = true;
								charImg = new Image("C://Users//DELL//Desktop/empty.jpg");
								ImageView emptyView = new ImageView(charImg);
								emptyView.setFitHeight(20);
								emptyView.setFitWidth(20);
								map.add(emptyView, i, j);
							}
								
						}
						characterCellButton.setOnMouseClicked(new EventHandler <Event>(){
							@Override
							public void handle(Event event) {
								selectedHero.setTarget(cellCharacter);
							}
							});
						if(!isEmpty) {
							Label characterName = new Label(cellCharacter.getName());
							ImageView charView = new ImageView(charImg);
							charView.setFitHeight(20);
							charView.setFitWidth(20);
							characterCellButton.setGraphic(charView);
							characterCellButton.setPrefSize(20, 20);
							buttonWithName.getChildren().addAll(characterName,characterCellButton);
							if(cellCharacter instanceof Hero) {
								Label actionsAvailable = new Label(((Hero)cellCharacter).getActionsAvailable() + " actions left");
								buttonWithName.getChildren().addAll(actionsAvailable);
							}
							map.add(buttonWithName, i, j);
						}
					} else {
						if(Game.map[i][j] instanceof TrapCell) {
							ImageView emptyView = new ImageView(new Image("C://Users//DELL//Desktop/empty.jpg"));
							emptyView.setFitHeight(20);
							emptyView.setFitWidth(20);
							map.add(emptyView, i, j);
						} else if(Game.map[i][j] instanceof CollectibleCell) {
							if(((CollectibleCell)Game.map[i][j]).getCollectible() instanceof Vaccine) {
								ImageView vaccineView = new ImageView(new Image("C://Users//DELL//Desktop/syringe.png"));
								vaccineView.setFitHeight(20);
								vaccineView.setFitWidth(20);
								map.add(vaccineView, i, j);
							} else {
								ImageView supplyView = new ImageView(new Image("C://Users//DELL//Desktop/supply.jpg"));
								supplyView.setFitHeight(20);
								supplyView.setFitWidth(20);
								map.add(supplyView, i, j);
							}
						}
					}
				}
			}
		}
		return map;
	}
}
