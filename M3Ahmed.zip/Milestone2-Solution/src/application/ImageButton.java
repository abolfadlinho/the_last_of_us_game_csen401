package application;

import javafx.scene.control.Button;

public class ImageButton extends Button {

    public ImageButton() {
    	setBackground(null);
    }
}
