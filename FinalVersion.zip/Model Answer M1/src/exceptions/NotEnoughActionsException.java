package exceptions;
@SuppressWarnings("serial")
public class NotEnoughActionsException extends GameActionException {

	public NotEnoughActionsException() {
		// TODO Auto-generated constructor stub
	}
	
	public NotEnoughActionsException(String message) {
		super(message);
	}

}
