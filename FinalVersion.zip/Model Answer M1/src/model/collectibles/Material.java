package model.collectibles;

public enum Material {
	PLASTIC, PAPER, METAL, WOOD;
}
