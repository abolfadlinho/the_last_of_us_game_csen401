package model.characters;

public class Zombie extends Character{
	private static int ZOMBIES_COUNT;
	
	public Zombie(){
		super("Zombie " + ZOMBIES_COUNT, 40, 10);
		
	}
	
	public static int getZOMBIES_COUNT() {
		return ZOMBIES_COUNT;
	}
	
	public static void setZOMBIES_COUNT(int zombies_count) {
		ZOMBIES_COUNT = zombies_count;
	}

}

