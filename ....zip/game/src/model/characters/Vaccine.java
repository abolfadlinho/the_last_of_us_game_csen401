package model.characters;

public class Vaccine {

}
