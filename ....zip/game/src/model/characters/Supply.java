package model.characters;

public class Supply {

}
